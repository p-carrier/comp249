/*
 * Philippe Carrier 40153985
 * COMP249 Section QQ
 * Assignment # 2
 * Friday, February 21, 2020
 *
 * Phase I
 * */

package package6;

/**
 * Class that build an FlyingObject instance
 *
 * @author Philippe Carrier
 */
public class FlyingObject {

    /**
     * Default constructor
     */
    public FlyingObject() {
    }

    /**
     * Copy constructor
     * @param flyingObject    @FlyingObject - Object to copy
     */
    public FlyingObject(FlyingObject flyingObject) {
    }
}
